// This file serves as a fallback handler for Vercel
// It imports and runs the main Express app

const app = require('../index.js');

module.exports = app;
